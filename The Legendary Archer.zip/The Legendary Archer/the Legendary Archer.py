
import pygame, random, sys, time
from pygame.locals import *
import time







#ประกาศค่าคงที่ไว้ทีเดียว #define or configulation
# set up some variables
class Monster:
    def __init__(self,rect,image):
        self.rect = rect
        self.image = image

    def monster_walker(self,monster1):
        for d in monster1:
            d.rect.move_ip(-1 * z_speed, 0)



    def monster_attack_by_arrow(self):
        for z in monster1:
            if has_Arrow_Hit_Monster(arrows, monster1):
                score += 1
                monster1.remove(z)


class Monster2(Monster):
    def __init__(self,rect,image,hp=3):
        self.rect = rect
        self.image = image
        self.hp = hp

    def monster2_walker(self,monster2):
        for c in monster2:
            c.rect.move_ip(-1 * z_speed - 5, 0)



    def has_Player_Hit_Monster(playerRect, monsters):
        for m in monsters:
            if playerRect.colliderect(m.rect):  # library pygame มองเป็นก้อนสี่เหลี่ยม
                return True
        return False

    def monster_attack_by_arrow2(self):
        for c in monster2:
            if has_Arrow_Hit_Monster2(arrows, monster2):
                c.hp -= 1
                if c.hp <= 0:
                    score += 1
                    monster2.remove(c)


class Monster3(Monster):
    def __init__(self, rect, image, hp=3):
        self.rect = rect
        self.image = image
        self.hp = hp

    def monster3_walker(self,monster3):
        for d in monster3:
            d.rect.move_ip(-1 * z_speed, 0)


    def has_Player_Hit_Monster(playerRect, monsters):
        for m in monsters:
            if playerRect.colliderect(m.rect):  # library pygame มองเป็นก้อนสี่เหลี่ยม
                return True
        return False
    def monster_attack_by_arrow3(self):
        for d in monster3:
            if has_Arrow_Hit_Monster3(arrows, monster3):
                d.hp -= 1
                if d.hp <= 0:
                    score += 1
                    monster3.remove(d)




class Arrow:
    def __init__(self, rect, image):
        self.rect = rect
        self.image = image





class Archer(Arrow):

    def move_ment_archer(self):
        if moveUp and ArcherRect.top > 100:  # ดูว่าplayerห่างจากหน้าจอเท่าไรถึงจะกดขี้นได้ไม่ได้
            ArcherRect.move_ip(0, -1 * PLAYERMOVERATE)  # 0,0อยู้ซ้ายบน ขยับขึ้นก็จะลบเพื่อทำให้เข้าใกล้0
        if moveDown and ArcherRect.bottom < WINDOWHEIGHT - 100:
            ArcherRect.move_ip(0, 1 * PLAYERMOVERATE)

    def has_Arrow_Hit_Monster(arrows, monsters):
        for b in arrows:
            if b.rect.colliderect(z.rect):
                arrows.remove(b)  # กระสุนหายไป
                return True  # wait player until use
        return False

    def has_Arrow_Hit_Monster2(arrows, monster2):
        for b in arrows:
            if b.rect.colliderect(c.rect):
                arrows.remove(b)
                return True
        return False

    def has_Arrow_Hit_Monster3(arrows, monster3):
        for b in arrows:
            if b.rect.colliderect(d.rect):
                arrows.remove(b)
                return True
        return False











WINDOWWIDTH = 1024
WINDOWHEIGHT = 600
FPS = 400

MAXGOTTENPASS = 3
MONSTERSIZE = 70  # includes newKindZombies
ADDNEWMONSTER1 = 30
ADDNEWMONSTER2 = 30
ADDNEWMONSTER3 = 30

NORMALMONSTERSPEED = 10
NEWKINDMONSTERSPEED = 10
NEWKINDMONSTER2SPEED = 10

PLAYERMOVERATE = 15 * 14
ARROWSPEED = 10
ADDNEWBULLETRATE = 3

TEXTCOLOR = (255, 255, 255) #white color 255 คือเต็ม


def terminate():
    pygame.quit()  # quit pygame
    sys.exit() # quit program


def wait_player_presskey(): # ตัวใหญ่มาจาก pygame local
    while True:
        for event in pygame.event.get():  # library in pygame
            if event.type == QUIT: # quit library in pygame local
                terminate()
            if event.type == KEYDOWN:
                if event.key == K_ESCAPE:  # pressing escape quits
                    terminate()
                if event.key == K_RETURN:
                    return


def has_Player_Hit_Monster(playerRect, monsters):
    for m in monsters:
        if playerRect.colliderect(m.rect): #library pygame มองเป็นก้อนสี่เหลี่ยม
            return True
    return False


def has_Arrow_Hit_Monster(arrows, monsters):
    for b in arrows:
        if b.rect.colliderect(z.rect):
            arrows.remove(b) #กระสุนหายไป
            return True #wait player until use
    return False


def has_Arrow_Hit_Monster2(arrows, monster2):
    for b in arrows:
        if b.rect.colliderect(c.rect):
            arrows.remove(b)
            return True
    return False

def has_Arrow_Hit_Monster3(arrows, monster3):
    for b in arrows:
        if b.rect.colliderect(d.rect):
            arrows.remove(b)
            return True
    return False

def load_image():
    ArcherImage = pygame.image.load('ARR_Archer.png')  # load picture
    ArcherRect = ArcherImage.get_rect()  # ขอชิ้นสี่เหลี่ยมตัวแทนรูปด้วย

    hpImage = pygame.image.load("heart3.png")
    hpRect = hpImage.get_rect()

    arrowImage = pygame.image.load('arrowfier.png')
    arrowRect = arrowImage.get_rect()

    MonsterImage = pygame.image.load('franken.png')
    Monster2Image = pygame.image.load('evilcat.png')
    Monster3Image = pygame.image.load('vampire.png')

    backgroundImage = pygame.image.load('background.png')
    re_scale_Background = pygame.transform.scale(backgroundImage, (
    WINDOWWIDTH, WINDOWHEIGHT))  # ขยายscale (re_size รูป)background ให้เท่ากับหน้าจอ

    backgroundImage2 = pygame.image.load('background2.png')
    re_scale_Background2 = pygame.transform.scale(backgroundImage2, (WINDOWWIDTH, WINDOWHEIGHT))

    backgroundImage3 = pygame.image.load('background3.png')
    re_scale_Background3 = pygame.transform.scale(backgroundImage3, (WINDOWWIDTH, WINDOWHEIGHT))

    background_Welcome_Image = pygame.image.load('background1.png')
    re_scale_Background_Welcome = pygame.transform.scale(background_Welcome_Image, (WINDOWWIDTH, WINDOWHEIGHT))

    # show the "Start" screen
    main_window.blit(re_scale_Background_Welcome, (0, 0))  # blit = ปะลงไปบนหน้่จอ ------- (0,0) --> ซ้ายบนเสมอ


def drawText(text, font, surface, x, y): # ดูตัวอย่างจาก library pygame
    textobj = font.render(text, 1, TEXTCOLOR) # เอาfontอะไร  text colorเอามาจากข้างบน
    textrect = textobj.get_rect() # text is rect และเอาคำปะลงไป
    textrect.topleft = (x, y)  # จากตำแหน่งมุมซ้ายบน x,y เป็นเท่าไร
    surface.blit(textobj, textrect) # ปะตัวอักษรลงไป


# set up pygame, the window, and the mouse cursor
pygame.init() # intial
mainClock = pygame.time.Clock() #ตัวจับเวลาจากpygame
main_window = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))   # create from myself window surfave หน้าจอโปรแกรม
pygame.display.set_caption('The Legendary Archer') #header program
pygame.mouse.set_visible(False) #ให้เมาส์หายไป

# set up fonts
font = pygame.font.SysFont(None, 48) #setขนาดfont


pygame.display.update() #update หน้าจอที่ปะไป
wait_player_presskey() # wait player press enter

main_window.blit(re_scale_Background, (0, 0)) #ปะ background หน้า2

while True:
    # set up the start of the game

    monster1 = [] #ตอนrungame ยังไม่มีzombie เลยประกาศว่างไว้
    monster2 = []
    monster3 = []
    arrows = [] #ยังไม่ได้ยิง

    monster_got_past = 0 #ซอมบี้ยังไม่ผ่าน
    score = 0

    ArcherRect.topleft = (123, (WINDOWHEIGHT / 2)) # ตัวplayer โผล่ตรงนี้

    moveLeft = False #เปิดมายังไม่มีการกดไรเลย
    moveRight = False
    moveUp = False
    moveDown = False
    shoot = False

    monsterAddCounter = 0 #ตัวนับเวลาที่ซอมบี้จะเกิดcooldown
    monster2AddCounter = 0 #ถ้าจะเอาซอมบี้อื่นก็มาเพิ่มตรงนี้
    monster3AddCounter = 0
    bulletAddCounter = 0 #cooldown กระสุน

    start_time = int(time.time()) #ขอเวลาตอนนี้ ใส่ในตัวแปร start time (กี๋โมงแล้ว) เพราะว่า ตั้งค่าเวลาไว้  <เวลาเริ่มต้น>
    win = False #ตอนนี้ยังไม่ win

    while True:  # the game loop runs while the game part is playing

        pass_time = int(time.time()) - start_time #เวลาปัจจุบัน - เวลาตอนเริ่ม ---> ผ่านไปกี่วิ (ex.ยกนาฬิกามาดูแล้วลบเวลาตอนเริ่ม)
        if pass_time > 60:
            win = True
            break
        if pass_time > 40:
            z_speed = NORMALMONSTERSPEED * 3 #ประกาศ z_speedจะได้เอาไปใช้ต่อ
            z_speed_text = '[3:%d]' % pass_time #บอกว่า textที่จะนำมาปริ้นเป็นคำว่าไร แค้คนละความเร็ว
        elif pass_time > 20:
            z_speed = NORMALMONSTERSPEED * 2
            z_speed_text = '[2:%d]' % pass_time
        else:
            z_speed = NORMALMONSTERSPEED
            z_speed_text = '[1:%d]' % pass_time

        if monster_got_past == 0: #zombie ผ่านไป0ตัว
            hpImage = pygame.image.load("heart3.png") #โหลดรูปหัวใจ
        elif monster_got_past == 1:
            hpImage = pygame.image.load("heart2.png")
        elif monster_got_past == 2:
            hpImage = pygame.image.load("heart1.png")
        hpRect = hpImage.get_rect() #วาดกรอปให้hp
        hpRect.topleft = (WINDOWWIDTH-200, 15) # ปรับตำแหน่งหัวใจ

        for event in pygame.event.get(): #ปิดตอนเล่น
            if event.type == QUIT:
                terminate()

            if event.type == KEYDOWN:
                if event.key == K_UP : #ดักให้กดปุ่มละยิงได้
                    moveDown = False
                    moveUp = True
                if event.key == K_DOWN :
                    moveUp = False
                    moveDown = True

                if event.key == K_SPACE:
                    shoot = True

            if event.type == KEYUP:
                if event.key == K_ESCAPE:
                    terminate()

                if event.key == K_UP :
                    moveUp = False
                if event.key == K_DOWN :
                    moveDown = False

                if event.key == K_SPACE:
                    shoot = False #หยุดยิง สั่งข้างล่างอีกที

        # Add new zombies at the top of the screen, if needed.
        monsterAddCounter += 1 #นับคูลดาวที่ซอบบี้เกิด
        if monsterAddCounter == ADDNEWMONSTER1: #ถ้าตรงกับconfigที่ตั้งไว้ก็จะเกิด
            monsterAddCounter = 0 #setค่า่zombie ให้เป็น0จะได้เกิดใหม่
            monsterSize = MONSTERSIZE #จับให้เท่ากับค่าที่ตั้งไว้

            # pos = random.randint(10, WINDOWHEIGHT - zombieSize - 10)
            r = random.randint(0, 2) #ทางที่ซอมบี้ออก
            main_block = WINDOWHEIGHT / 3 # บล๊อคช่องใหญ่ๆจับหาร3ได้3ช่อง
            init_block = main_block / 2 #เอาblockที่หารแล้วมาหาร2
            position_mon = r * main_block + init_block #ตำแหน่งของซอมบี้

            # newZombie = { #
            #     'rect': pygame.Rect(WINDOWWIDTH, pos, zombieSize,
            #                         zombieSize), #จะสร้างrectต้องใส่ ตำแหน่ง ขนาด
            #     'image': pygame.transform.scale(zombieImage, (zombieSize, zombieSize)), #สร้างรูปร่าง
            # }

            newMonster = Monster(pygame.Rect(WINDOWWIDTH, position_mon, monsterSize, monsterSize),
                                 pygame.transform.scale(MonsterImage, (monsterSize, monsterSize))


                                 )
            monster1.append(newMonster)  #คำสั่งต่อท้ายlist ซอมบี้จะได้เพิ่ืมเข้ามาในlist

        # Add new newKindZombies at the top of the screen, if needed.
        monster2AddCounter += 1
        if monster2AddCounter == ADDNEWMONSTER2:
            monster2AddCounter = 0
            monster2_size = MONSTERSIZE

            # pos = random.randint(10, WINDOWHEIGHT - zombieSize - 10)
            r = random.randint(0, 2)
            main_block = WINDOWHEIGHT / 3
            init_block = main_block / 2
            position_mon = r * main_block + init_block

            # newZombie = {
            #     'rect': pygame.Rect(WINDOWWIDTH, pos, zombieSize,
            #                         zombieSize),
            #     'image': pygame.transform.scale(newKindZombieImage, (zombieSize, zombieSize)),
            #     'hp': 3 #ต้องมี
            # }
            newMonster = Monster2(pygame.Rect(WINDOWWIDTH, position_mon, monsterSize, monsterSize),
                                  pygame.transform.scale(Monster2Image, (monsterSize, monsterSize)), 2)

            monster2.append(newMonster)

        monster3AddCounter += 1
        if monster3AddCounter == ADDNEWMONSTER3:
            monster3AddCounter = 0
            monster3_size = MONSTERSIZE

            # pos = random.randint(10, WINDOWHEIGHT - zombieSize - 10)
            r = random.randint(0, 2)
            main_block = WINDOWHEIGHT / 3
            init_block = main_block / 2
            position_mon = r * main_block + init_block

            # newZombie = {
            #     'rect': pygame.Rect(WINDOWWIDTH, pos, zombieSize,
            #                         zombieSize),
            #     'image': pygame.transform.scale(newKindZombieImage, (zombieSize, zombieSize)),
            #     'hp': 2 #ต้องมี
            # }
            newMonster = Monster3(pygame.Rect(WINDOWWIDTH, position_mon, monsterSize, monsterSize),
                                  pygame.transform.scale(Monster3Image, (monsterSize, monsterSize)), 3)
            monster3.append(newMonster)

        # add new bullet
        bulletAddCounter += 1
        if bulletAddCounter >= ADDNEWBULLETRATE and shoot == True:
            bulletAddCounter = 0
            # newBullet = {'rect': pygame.Rect(playerRect.centerx + 10, playerRect.centery - 25, bulletRect.width, #ปรับตำแหน่งที่กระสุนจะออก
            #                                  bulletRect.height),
            #              'image': pygame.transform.scale(bulletImage, (bulletRect.width, bulletRect.height)), #เอามายัดใส่image ให้แสดงผล
            #              }

            newArrow = Arrow(pygame.Rect(ArcherRect.centerx + 10, ArcherRect.centery - 25, arrowRect.width,  #ปรับตำแหน่งที่กระสุนจะออก
                                         arrowRect.height), pygame.transform.scale(arrowImage, (arrowRect.width, arrowRect.height))

                             )
            arrows.append(newArrow) #มีการกดbulletเพิ่มก็แอดเข้าไป

        # Move the player around.
        if moveUp and ArcherRect.top > 100: #ดูว่าplayerห่างจากหน้าจอเท่าไรถึงจะกดขี้นได้ไม่ได้
            ArcherRect.move_ip(0, -1 * PLAYERMOVERATE) #0,0อยู้ซ้ายบน ขยับขึ้นก็จะลบเพื่อทำให้เข้าใกล้0
        if moveDown and ArcherRect.bottom < WINDOWHEIGHT - 100:
            ArcherRect.move_ip(0, 1 * PLAYERMOVERATE)

        for z in monster1:
            z.rect.move_ip(-1 * z_speed-10, 0) #xเปลี่ยนyไม่เปลี่ยน ขยับซ้าย = -1 (เอาค่ามาจากz_speedว่าตั้งไว้เท่าไร)

        for c in monster2:
            c.rect.move_ip(-1 * z_speed-5, 0)

        for d in monster3:
            d.rect.move_ip(-1 * z_speed, 0)


        # move the bullet
        for b in arrows:
            b.rect.move_ip(1 * ARROWSPEED, 0) #กระสุนไปขวา x+ ,y=0เพราะyไม่เปลี่ยน อยู่ตรงไหนก็ตรงนั้น

        # Delete zombies that have fallen past the bottom.
        for z in monster1[:]:
            if z.rect.left < 0: #zombieทะลุจอไปแล้ว
                monster1.remove(z) #ให้เอาออก
                monster_got_past += 1 #นับตัวที่ผ่านไป

        for c in monster2[:]:
            if c.rect.left < 0:
                monster2.remove(c)
                monster_got_past += 1

        for d in monster3[:]:
            if d.rect.left < 0:
                monster3.remove(d)
                monster_got_past += 1


        for b in arrows[:]:
            if b.rect.right > WINDOWWIDTH: #bulletทะลุจอ เอาออกไปเฉยๆ
                arrows.remove(b)

        # check if the bullet has hit the zombie
        for z in monster1:
            if has_Arrow_Hit_Monster(arrows, monster1):
                score += 1
                monster1.remove(z)

        for c in monster2:
            if has_Arrow_Hit_Monster2(arrows, monster2):
                c.hp -= 1
                if c.hp <= 0:
                    score += 1
                    monster2.remove(c)

        for d in monster3:
            if has_Arrow_Hit_Monster3(arrows, monster3):
                d.hp -= 1
                if d.hp <= 0:
                    score += 1
                    monster3.remove(d)

                # Draw the game world on the window.

         #คำนวณให้เสร็จแล้วแสดงผล
        main_window.blit(re_scale_Background, (0, 0)) #เริ่มเอารูปปะลงหน้าจอ

        # Draw the player's rectangle, rails
        main_window.blit(ArcherImage, ArcherRect) #ค่อยแปะplayer จะได้ไม่ทับกัน
        main_window.blit(hpImage, hpRect)

        # Draw each bahas_Bullet_Hit_Monsterddie
        for z in monster1: #loop ซอมบี้ทุกตัว แล้วเอาแต่ละตัวไป blit .ใส่ main window
            main_window.blit(z.image, z.rect) #dictionary

        for c in monster2:
            main_window.blit(c.image, c.rect)

        for d in monster3:
            main_window.blit(d.image, d.rect)

        # draw each bullet
        for b in arrows:
            main_window.blit(b.image, b.rect)

        # Draw the score and how many zombies got past
        # drawText(f'zombies gotten past: {zombiesGottenPast}', font, main_window, 10, 20) #ฟังก์ชั้นเขียนเอง
        drawText(f'score: {score}', font, main_window, 10, 20) #f is format ยัดค่าตัวแปรใส่ได้เลย

        drawText(z_speed_text, font, main_window, (WINDOWWIDTH / 2), 20)

        # update the display
        pygame.display.update()

        # Check if any of the zombies has hit the player.
        if has_Player_Hit_Monster(ArcherRect, monster1):
            break
        if has_Player_Hit_Monster(ArcherRect, monster2):
            break
        if has_Player_Hit_Monster(ArcherRect, monster3):
            break

        # check if score is over MAXGOTTENPASS which means game over
        if monster_got_past >= MAXGOTTENPASS:
            break

        mainClock.tick(FPS)

    time.sleep(1) #รอdelay 1s ตอนเกม over
    main_window.blit(re_scale_Background3, (0, 0)) #เปลี่ยน background
    pygame.display.update()
    if win:
        drawText('win score: %s' % score, font, main_window, 10, 30)
        pygame.display.update()
        wait_player_presskey()
    elif monster_got_past >= MAXGOTTENPASS:
        main_window.blit(re_scale_Background2, (0, 0))

        drawText('score: %s' % (score), font, main_window, 10, 30)
        drawText('GAME OVER', font, main_window, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
        drawText('YOUR DIE', font, main_window, (WINDOWWIDTH / 2) - 180,
                 (WINDOWHEIGHT / 3) + 100)
        drawText('Press enter to play again or  exit to close the game', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 150)

        pygame.display.update()
        wait_player_presskey()
    elif has_Player_Hit_Monster(ArcherRect, monster1):
        main_window.blit(re_scale_Background2, (0, 0))
        drawText('score: %s' % (score), font, main_window, 10, 30)
        drawText('GAME OVER', font, main_window, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
        drawText('YOU HAVE  HIT WITH MONSTER', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 100)
        drawText('Press enter to play again or  exit to close the game', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 150)

        pygame.display.update()
        wait_player_presskey()

    elif has_Player_Hit_Monster(ArcherRect, monster2):
        main_window.blit(re_scale_Background2, (0, 0))
        drawText('score: %s' % (score), font, main_window, 10, 30)
        drawText('GAME OVER', font, main_window, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
        drawText('YOU HAVE  HIT WITH MONSTER', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 100)
        drawText('Press enter to play again or  exit to close the game', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 150)

        pygame.display.update()
        wait_player_presskey()
    elif has_Player_Hit_Monster(ArcherRect, monster3):
        main_window.blit(re_scale_Background2, (0, 0))
        drawText('score: %s' % (score), font, main_window, 10, 30)
        drawText('GAME OVER', font, main_window, (WINDOWWIDTH / 3), (WINDOWHEIGHT / 3))
        drawText('YOU HAVE  HIT WITH MONSTER', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 100)
        drawText('Press enter to play again or  exit to close the game', font, main_window, (WINDOWWIDTH / 4) - 80,
                 (WINDOWHEIGHT / 3) + 150)

        pygame.display.update()
        wait_player_presskey()